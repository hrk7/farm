public class Potato {
    private double mass;
    private final double growthRate = 0.5;

    public Potato(double initialMass) {
        this.mass = initialMass;
    }
    public void grow() {
        this.mass += growthRate;
    }
    public void consume(double amount) {
        this.mass = Math.max(0, this.mass - amount);
    }
    public double getMass() { return mass; }
}

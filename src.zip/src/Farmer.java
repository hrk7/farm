public class Farmer {
    private final double protectionRadius = 10.0; // Przykładowy zasięg działania

    public void protect(Fox fox, ColoradoBeetle beetle) {
        if (fox != null) {
            System.out.println("Farmer przepędza lisa!");
            // Logika odstraszania lisa
        }

        if (beetle != null && beetle.isAlive()) {
            System.out.println("Farmer eliminuje stonkę opryskiem.");
            beetle.die();
        }
    }

    public void harvest(Potato potato) {
        if (potato.getMass() > 5.0) {
            System.out.println("Farmer zebrał plony.");
            potato.consume(potato.getMass());
        }
    }
}


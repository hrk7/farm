public class ColoradoBeetle {
    private boolean isAlive = true;

    public void eat(Potato potato) {
        if (potato.getMass() > 0) {
            potato.consume(1.0); // Zjada określoną jednostkę masy
            System.out.println("Stonka żeruje na ziemniaku.");
        }
    }
    public void die() { this.isAlive = false; }
    public boolean isAlive() { return isAlive; }
}
public class Fox {
    public void hunt(Chicken chicken) {
        if (chicken.isAlive()) {
            System.out.println("Lis upolował kurę!");
            chicken.die();
        }
    }
}


public class Chicken {
    private boolean isAlive = true;
    public void interact(ColoradoBeetle beetle, Potato potato) {
        if (beetle != null && beetle.isAlive()) {
            System.out.println("Kura zjada stonkę!");
            beetle.die();
        } else if (potato.getMass() > 0) {
            System.out.println("Brak stonki. Kura podjada ziemniaka.");
            potato.consume(0.5);
        }
    }
    public void die() { this.isAlive = false; }
    public boolean isAlive() { return isAlive; }
}